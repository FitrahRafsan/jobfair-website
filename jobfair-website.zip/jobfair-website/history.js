// history.js

// Check authentication
function checkAuth() {
    const currentUser = localStorage.getItem('currentUser');
    if (!currentUser) {
        alert('⚠️ Silakan login terlebih dahulu!');
        window.location.href = 'login.html';
        return null;
    }
    return JSON.parse(currentUser);
}

const user = checkAuth();
if (user) {
    document.getElementById('userName').textContent = user.name;
    document.getElementById('userEmail').textContent = user.email;
}

// Logout handler
document.getElementById('logoutBtn').addEventListener('click', function() {
    if (confirm('Apakah Anda yakin ingin logout?')) {
        localStorage.removeItem('currentUser');
        window.location.href = 'login.html';
    }
});

// Format file size
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
}

// Download CV
function downloadCV(appId) {
    const applications = JSON.parse(localStorage.getItem('applications') || '[]');
    const app = applications.find(a => a.id === appId);
    
    if (app && app.cvFile) {
        const link = document.createElement('a');
        link.href = app.cvFile;
        link.download = app.cvFileName || 'CV.pdf';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        alert('✅ CV berhasil didownload!');
    } else {
        alert('❌ CV tidak ditemukan!');
    }
}

// View application details
function viewDetails(appId) {
    const applications = JSON.parse(localStorage.getItem('applications') || '[]');
    const app = applications.find(a => a.id === appId);
    
    if (app) {
        const details = `
═══════════════════════════════════════
📋 DETAIL LAMARAN
═══════════════════════════════════════

🏢 PEKERJAAN:
   ${app.jobTitle}
   ${app.company}

👤 PELAMAR:
   Nama: ${app.name}
   Email: ${app.email}
   Phone: ${app.phone}

🎓 PENDIDIKAN:
   ${app.education} - ${app.major}
   Pengalaman: ${app.experience} tahun

💰 EKSPEKTASI GAJI:
   Rp ${parseInt(app.expectedSalary).toLocaleString('id-ID')}

📍 ALAMAT:
   ${app.address}

💼 TENTANG SAYA:
   ${app.about}

📄 CV:
   ${app.cvFileName || 'Tidak ada'} ${app.cvFileSize ? '(' + formatFileSize(app.cvFileSize) + ')' : ''}

📅 TANGGAL PENGAJUAN:
   ${app.date}

📊 STATUS:
   ${app.status}

═══════════════════════════════════════
        `;
        alert(details);
    }
}

// Populate history
function populateHistory() {
    const applications = JSON.parse(localStorage.getItem('applications') || '[]');
    const userApplications = applications.filter(app => app.userId === user.id);
    const container = document.getElementById('historyList');
    
    if (userApplications.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-inbox"></i>
                <h3>Belum Ada Riwayat Lamaran</h3>
                <p>Anda belum mengajukan lamaran apapun. Mulai lamar pekerjaan sekarang!</p>
                <br>
                <a href="apply-job.html" class="btn-primary" style="display: inline-block; text-decoration: none; width: auto; padding: 15px 40px;">
                    <i class="fas fa-plus"></i> Ajukan Lamaran
                </a>
            </div>
        `;
        return;
    }
    
    // Sort by date (newest first) - approximate sort by id
    userApplications.sort((a, b) => b.id - a.id);
    
    container.innerHTML = userApplications.map(app => {
        const statuses = ['Pending', 'In Review', 'Accepted', 'Rejected'];
        const statusClasses = ['status-pending', 'status-review', 'status-accepted', 'status-rejected'];
        const statusIndex = statuses.indexOf(app.status);
        
        return `
            <div class="status-item">
                <span class="status-badge ${statusClasses[statusIndex]}">${app.status}</span>
                <div class="job-title">${app.jobTitle}</div>
                <div class="job-company"><i class="fas fa-building"></i> ${app.company}</div>
                <div class="job-details" style="margin-top: 15px;">
                    <div class="job-detail-item">
                        <i class="fas fa-graduation-cap"></i> ${app.education}${app.major ? ' - ' + app.major : ''}
                    </div>
                    <div class="job-detail-item">
                        <i class="fas fa-briefcase"></i> ${app.experience} tahun pengalaman
                    </div>
                    <div class="job-detail-item">
                        <i class="fas fa-money-bill-wave"></i> Ekspektasi: Rp ${parseInt(app.expectedSalary).toLocaleString('id-ID')}
                    </div>
                    ${app.cvFileName ? `
                    <div class="job-detail-item">
                        <i class="fas fa-file-pdf" style="color: #ef4444;"></i> CV: ${app.cvFileName} (${formatFileSize(app.cvFileSize)})
                    </div>
                    ` : ''}
                </div>
                <div class="application-date" style="display: flex; justify-content: space-between; align-items: center; margin-top: 15px;">
                    <span>
                        <i class="fas fa-calendar"></i> Diajukan pada ${app.date}
                    </span>
                    <div style="display: flex; gap: 10px;">
                        ${app.cvFile ? `
                        <button onclick="downloadCV(${app.id})" style="padding: 8px 15px; background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%); color: white; border: none; border-radius: 8px; cursor: pointer; font-size: 12px; font-weight: 600; transition: all 0.3s;" onmouseover="this.style.transform='translateY(-2px)'" onmouseout="this.style.transform='translateY(0)'">
                            <i class="fas fa-download"></i> Download CV
                        </button>
                        ` : ''}
                        <button onclick="viewDetails(${app.id})" style="padding: 8px 15px; background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; border: none; border-radius: 8px; cursor: pointer; font-size: 12px; font-weight: 600; transition: all 0.3s;" onmouseover="this.style.transform='translateY(-2px)'" onmouseout="this.style.transform='translateY(0)'">
                            <i class="fas fa-eye"></i> Lihat Detail
                        </button>
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

// Initialize
populateHistory();