// notifications.js

// Check authentication
function checkAuth() {
    const currentUser = localStorage.getItem('currentUser');
    if (!currentUser) {
        alert('⚠️ Silakan login terlebih dahulu!');
        window.location.href = 'login.html';
        return null;
    }
    return JSON.parse(currentUser);
}

const user = checkAuth();
if (user) {
    document.getElementById('userName').textContent = user.name;
    document.getElementById('userEmail').textContent = user.email;
}

// Logout handler
document.getElementById('logoutBtn').addEventListener('click', function() {
    if (confirm('Apakah Anda yakin ingin logout?')) {
        localStorage.removeItem('currentUser');
        window.location.href = 'login.html';
    }
});

// Get or create notifications
function getNotifications() {
    let notifications = localStorage.getItem('notifications');
    if (!notifications) {
        // Create demo notifications based on user applications
        const applications = JSON.parse(localStorage.getItem('applications') || '[]');
        const userApplications = applications.filter(app => app.userId === user.id);
        
        const demoNotifications = [
            {
                id: 1,
                userId: user.id,
                type: 'success',
                icon: 'fa-check-circle',
                title: 'Selamat Datang di CareerHub!',
                message: 'Terima kasih telah bergabung dengan kami. Mulai lamar pekerjaan impian Anda sekarang!',
                time: 'Baru saja',
                read: false
            },
            {
                id: 2,
                userId: user.id,
                type: 'info',
                icon: 'fa-info-circle',
                title: 'Tips Melamar Kerja',
                message: 'Pastikan CV Anda sudah update dan sesuaikan dengan posisi yang Anda lamar untuk meningkatkan peluang diterima.',
                time: '5 menit yang lalu',
                read: false
            },
            {
                id: 3,
                userId: user.id,
                type: 'warning',
                icon: 'fa-briefcase',
                title: '12 Lowongan Baru Tersedia',
                message: 'Ada 12 lowongan pekerjaan baru yang mungkin cocok untuk Anda. Lihat dan lamar sekarang!',
                time: '1 jam yang lalu',
                read: true
            }
        ];

        // Add notifications for each application
        userApplications.forEach((app, index) => {
            demoNotifications.push({
                id: 100 + index,
                userId: user.id,
                type: 'success',
                icon: 'fa-paper-plane',
                title: `Lamaran Berhasil Dikirim - ${app.jobTitle}`,
                message: `Lamaran Anda untuk posisi ${app.jobTitle} di ${app.company} telah berhasil dikirim. Kami akan segera meninjau lamaran Anda.`,
                time: `${app.date}`,
                read: index === 0 ? false : true
            });
        });

        localStorage.setItem('notifications', JSON.stringify(demoNotifications));
        return demoNotifications;
    }
    return JSON.parse(notifications);
}

// Current filter
let currentFilter = 'all';

// Filter notifications
function filterNotifications(filter) {
    currentFilter = filter;
    
    // Update active tab
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.closest('.tab-btn').classList.add('active');
    
    populateNotifications();
}

// Populate notifications
function populateNotifications() {
    const allNotifications = getNotifications();
    const userNotifications = allNotifications.filter(notif => notif.userId === user.id);
    
    let filteredNotifications = userNotifications;
    if (currentFilter === 'unread') {
        filteredNotifications = userNotifications.filter(n => !n.read);
    } else if (currentFilter === 'read') {
        filteredNotifications = userNotifications.filter(n => n.read);
    }
    
    const container = document.getElementById('notificationsList');
    
    if (filteredNotifications.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-bell-slash"></i>
                <h3>Tidak Ada Notifikasi</h3>
                <p>Belum ada notifikasi ${currentFilter === 'unread' ? 'yang belum dibaca' : currentFilter === 'read' ? 'yang sudah dibaca' : ''} untuk saat ini.</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = filteredNotifications.map(notif => `
        <div class="notification-item ${!notif.read ? 'unread' : ''}" onclick="markAsRead(${notif.id})">
            <div class="notification-icon ${notif.type}">
                <i class="fas ${notif.icon}"></i>
            </div>
            <div class="notification-content">
                <div class="notification-title">
                    ${notif.title}
                    ${!notif.read ? '<span class="unread-badge"></span>' : ''}
                </div>
                <div class="notification-message">${notif.message}</div>
                <div class="notification-time">
                    <i class="fas fa-clock"></i> ${notif.time}
                </div>
            </div>
        </div>
    `).join('');
}

// Mark notification as read
function markAsRead(notifId) {
    const notifications = getNotifications();
    const notifIndex = notifications.findIndex(n => n.id === notifId);
    
    if (notifIndex !== -1 && !notifications[notifIndex].read) {
        notifications[notifIndex].read = true;
        localStorage.setItem('notifications', JSON.stringify(notifications));
        populateNotifications();
    }
}

// Mark all as read
function markAllAsRead() {
    const notifications = getNotifications();
    notifications.forEach(notif => {
        if (notif.userId === user.id) {
            notif.read = true;
        }
    });
    localStorage.setItem('notifications', JSON.stringify(notifications));
    populateNotifications();
    alert('✅ Semua notifikasi telah ditandai sebagai sudah dibaca!');
}

// Initialize
populateNotifications();