// company-questions.js

// Check authentication
function checkAuth() {
    const currentUser = localStorage.getItem('currentUser');
    if (!currentUser) {
        alert('⚠️ Silakan login terlebih dahulu!');
        window.location.href = 'login.html';
        return null;
    }
    return JSON.parse(currentUser);
}

const user = checkAuth();
if (user) {
    document.getElementById('userName').textContent = user.name;
    document.getElementById('userEmail').textContent = user.email;
}

// Logout handler
document.getElementById('logoutBtn').addEventListener('click', function() {
    if (confirm('Apakah Anda yakin ingin logout?')) {
        localStorage.removeItem('currentUser');
        window.location.href = 'login.html';
    }
});

// Sample company questions
const companyQuestions = [
    {
        id: 1,
        company: "Tech Innovators Inc.",
        jobPosition: "Senior Full Stack Developer",
        question: "Ceritakan pengalaman Anda dalam mengembangkan aplikasi full-stack dan teknologi apa saja yang Anda kuasai?",
        askedDate: "22 November 2025",
        deadline: "30 November 2026",
        type: "online",
        answered: false
    },
    {
        id: 2,
        company: "Creative Digital Studio",
        jobPosition: "UI/UX Designer",
        question: "Apa pendekatan Anda dalam mendesain user interface yang user-friendly? Berikan contoh project yang pernah Anda kerjakan.",
        askedDate: "21 November 2025",
        deadline: "28 November 2026",
        type: "online",
        answered: false
    },
    {
        id: 3,
        company: "AI Solutions Corp",
        jobPosition: "Data Scientist",
        question: "Jelaskan pengalaman Anda dengan machine learning dan algoritma apa yang paling sering Anda gunakan dalam analisis data?",
        askedDate: "20 November 2025",
        deadline: "29 November 2026",
        type: "offline",
        answered: false
    },
    {
        id: 4,
        company: "Brand Excellence Co.",
        jobPosition: "Marketing Manager",
        question: "Bagaimana strategi marketing digital yang pernah Anda terapkan dan hasil yang dicapai? Berikan contoh campaign yang sukses.",
        askedDate: "23 November 2025",
        deadline: "01 Desember 2026",
        type: "online",
        answered: false
    },
    {
        id: 5,
        company: "StartUp Ventures",
        jobPosition: "Backend Developer (Node.js)",
        question: "Ceritakan pengalaman Anda dalam membangun RESTful API menggunakan Node.js. Bagaimana Anda handle security dan scalability?",
        askedDate: "19 November 2025",
        deadline: "27 November 2026",
        type: "online",
        answered: false
    }
];

// Get or initialize answers
function getAnswers() {
    return JSON.parse(localStorage.getItem('companyAnswers') || '[]');
}

function saveAnswer(questionId, answer) {
    const answers = getAnswers();
    const existingIndex = answers.findIndex(a => a.questionId === questionId && a.userId === user.id);
    
    const answerData = {
        id: existingIndex >= 0 ? answers[existingIndex].id : Date.now(),
        questionId: questionId,
        userId: user.id,
        answer: answer,
        answeredDate: new Date().toLocaleDateString('id-ID', { 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
        }),
        answeredTime: new Date().toLocaleTimeString('id-ID', {
            hour: '2-digit',
            minute: '2-digit'
        })
    };
    
    if (existingIndex >= 0) {
        answers[existingIndex] = answerData;
    } else {
        answers.push(answerData);
    }
    
    localStorage.setItem('companyAnswers', JSON.stringify(answers));
}

// Current filter
let currentFilter = 'all';

// Filter questions
window.filterQuestions = function(filter) {
    currentFilter = filter;
    
    // Update active tab
    document.querySelectorAll('.filter-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Find and activate the correct tab
    const tabs = document.querySelectorAll('.filter-tab');
    if (filter === 'all') tabs[0].classList.add('active');
    else if (filter === 'unanswered') tabs[1].classList.add('active');
    else if (filter === 'answered') tabs[2].classList.add('active');
    
    populateQuestions();
};

// Check if deadline passed
function isDeadlinePassed(deadline) {
    const deadlineDate = new Date(deadline);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return deadlineDate < today;
}

// Get days until deadline
function getDaysUntilDeadline(deadline) {
    const deadlineDate = new Date(deadline);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const diff = deadlineDate - today;
    const days = Math.ceil(diff / (1000 * 60 * 60 * 24));
    
    if (days < 0) return "Terlewat";
    if (days === 0) return "Hari ini";
    if (days === 1) return "Besok";
    return `${days} hari lagi`;
}

// Populate questions
function populateQuestions() {
    const answers = getAnswers();
    const container = document.getElementById('questionsList');
    
    // Filter questions
    let filteredQuestions = companyQuestions.map(q => {
        const userAnswer = answers.find(a => a.questionId === q.id && a.userId === user.id);
        return { ...q, userAnswer };
    });
    
    if (currentFilter === 'answered') {
        filteredQuestions = filteredQuestions.filter(q => q.userAnswer);
    } else if (currentFilter === 'unanswered') {
        filteredQuestions = filteredQuestions.filter(q => !q.userAnswer);
    }
    
    if (filteredQuestions.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-comments"></i>
                <h3>Tidak Ada Pertanyaan</h3>
                <p>Belum ada pertanyaan ${currentFilter === 'answered' ? 'yang sudah dijawab' : currentFilter === 'unanswered' ? 'yang belum dijawab' : ''} saat ini.</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = filteredQuestions.map(q => {
        const isAnswered = !!q.userAnswer;
        const deadlinePassed = isDeadlinePassed(q.deadline);
        const daysUntil = getDaysUntilDeadline(q.deadline);
        
        return `
            <div class="question-card">
                <div class="question-header">
                    <div class="company-info">
                        <div class="company-name">
                            <i class="fas fa-building"></i> ${q.company}
                        </div>
                        <div class="job-position">${q.jobPosition}</div>
                    </div>
                    <span class="question-badge ${isAnswered ? 'badge-answered' : 'badge-unanswered'}">
                        ${isAnswered ? '✅ Sudah Dijawab' : '⏳ Belum Dijawab'}
                    </span>
                </div>
                
                <div class="question-content">
                    <div class="question-label">Pertanyaan:</div>
                    <div class="question-text">${q.question}</div>
                </div>
                
                <div class="answer-section" id="answer-section-${q.id}">
                    ${isAnswered ? `
                        <div class="question-label">Jawaban Anda:</div>
                        <div class="answer-display" id="answer-display-${q.id}">
                            ${q.userAnswer.answer}
                        </div>
                        <div class="question-actions">
                            <button class="btn-edit" onclick="editAnswer(${q.id})">
                                <i class="fas fa-edit"></i> Edit Jawaban
                            </button>
                        </div>
                    ` : `
                        <div class="answer-form" id="answer-form-${q.id}">
                            <div class="question-label">Jawaban Anda:</div>
                            <textarea id="answer-input-${q.id}" 
                                      placeholder="Tulis jawaban Anda di sini...${deadlinePassed ? ' (Deadline sudah lewat)' : ''}"
                                      ${deadlinePassed ? 'disabled' : ''}></textarea>
                            ${!deadlinePassed ? `
                                <div class="question-actions">
                                    <button class="btn-answer" onclick="submitAnswer(${q.id})">
                                        <i class="fas fa-paper-plane"></i> Kirim Jawaban
                                    </button>
                                </div>
                            ` : ''}
                        </div>
                    `}
                </div>
                
                <div class="question-meta">
                    <div class="meta-item">
                        <i class="fas fa-calendar"></i>
                        <span>Ditanya: ${q.askedDate}</span>
                    </div>
                    <div class="meta-item">
                        <i class="fas fa-clock"></i>
                        <span>Deadline: ${q.deadline} ${!deadlinePassed && !isAnswered ? '(' + daysUntil + ')' : ''}</span>
                    </div>
                    <div class="meta-item">
                        <i class="fas fa-${q.type === 'online' ? 'laptop' : 'map-marker-alt'}"></i>
                        <span>${q.type === 'online' ? 'Tes Online' : 'Tes Offline'}</span>
                    </div>
                    ${isAnswered ? `
                        <div class="meta-item">
                            <i class="fas fa-check"></i>
                            <span>Dijawab: ${q.userAnswer.answeredDate}</span>
                        </div>
                    ` : ''}
                </div>
            </div>
        `;
    }).join('');
}

// Submit answer - Make it global
window.submitAnswer = function(questionId) {
    const answer = document.getElementById(`answer-input-${questionId}`).value.trim();
    
    if (!answer) {
        alert('❌ Silakan isi jawaban terlebih dahulu!');
        return;
    }
    
    if (answer.length < 50) {
        if (!confirm('⚠️ Jawaban Anda kurang dari 50 karakter.\n\nApakah Anda yakin jawaban sudah lengkap?')) {
            return;
        }
    }
    
    const question = companyQuestions.find(q => q.id === questionId);
    
    if (confirm(`📤 Kirim Jawaban\n\n` +
                `Perusahaan: ${question.company}\n` +
                `Posisi: ${question.jobPosition}\n\n` +
                `Apakah Anda yakin ingin mengirim jawaban ini?`)) {
        
        saveAnswer(questionId, answer);
        
        // Add notification
        const notifications = JSON.parse(localStorage.getItem('notifications') || '[]');
        notifications.push({
            id: Date.now(),
            userId: user.id,
            type: 'success',
            icon: 'fa-check-circle',
            title: 'Jawaban Berhasil Dikirim',
            message: `Jawaban Anda untuk pertanyaan dari ${question.company} telah berhasil dikirim. HRD akan segera meninjau jawaban Anda.`,
            time: 'Baru saja',
            read: false
        });
        localStorage.setItem('notifications', JSON.stringify(notifications));
        
        alert('✅ Jawaban berhasil dikirim!\n\nTerima kasih telah menjawab pertanyaan dari perusahaan.');
        populateQuestions();
    }
};

// Edit answer - Make it global
window.editAnswer = function(questionId) {
    const answers = getAnswers();
    const answer = answers.find(a => a.questionId === questionId && a.userId === user.id);
    
    if (!answer) return;
    
    const section = document.getElementById(`answer-section-${questionId}`);
    section.innerHTML = `
        <div class="answer-form">
            <div class="question-label">Edit Jawaban Anda:</div>
            <textarea id="edit-answer-input-${questionId}" 
                      placeholder="Edit jawaban Anda...">${answer.answer}</textarea>
            <div class="question-actions">
                <button class="btn-answer" onclick="saveEditedAnswer(${questionId})">
                    <i class="fas fa-save"></i> Simpan Perubahan
                </button>
                <button class="btn-cancel" onclick="cancelEdit()">
                    <i class="fas fa-times"></i> Batal
                </button>
            </div>
        </div>
    `;
};

// Save edited answer - Make it global
window.saveEditedAnswer = function(questionId) {
    const newAnswer = document.getElementById(`edit-answer-input-${questionId}`).value.trim();
    
    if (!newAnswer) {
        alert('❌ Jawaban tidak boleh kosong!');
        return;
    }
    
    if (confirm('💾 Simpan perubahan jawaban?')) {
        saveAnswer(questionId, newAnswer);
        alert('✅ Jawaban berhasil diperbarui!');
        populateQuestions();
    }
};

// Cancel edit - Make it global
window.cancelEdit = function() {
    populateQuestions();
};

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    populateQuestions();
});

// Also initialize immediately
populateQuestions();