// online-test.js

// Check authentication
function checkAuth() {
    const currentUser = localStorage.getItem('currentUser');
    if (!currentUser) {
        alert('⚠️ Silakan login terlebih dahulu!');
        window.location.href = 'login.html';
        return null;
    }
    return JSON.parse(currentUser);
}

const user = checkAuth();
if (user) {
    document.getElementById('userName').textContent = user.name;
    document.getElementById('userEmail').textContent = user.email;
}

// Logout handler
document.getElementById('logoutBtn').addEventListener('click', function() {
    if (confirm('Apakah Anda yakin ingin logout?')) {
        localStorage.removeItem('currentUser');
        window.location.href = 'login.html';
    }
});

// Sample test data (based on jobs)
const onlineTests = [
    {
        id: 1,
        jobTitle: "Senior Full Stack Developer",
        company: "Tech Innovators Inc.",
        testDate: "2025-12-28",
        testTime: "10:00",
        duration: 60,
        questions: 20,
        status: "active",
        type: "online"
    },
    {
        id: 2,
        jobTitle: "UI/UX Designer",
        company: "Creative Digital Studio",
        testDate: "2025-12-29",
        testTime: "14:00",
        duration: 45,
        questions: 15,
        status: "active",
        type: "online"
    },
    {
        id: 3,
        jobTitle: "Data Scientist",
        company: "AI Solutions Corp",
        testDate: "2025-11-29",
        testTime: "09:00",
        duration: 90,
        questions: 30,
        status: "upcoming",
        type: "offline"
    },
    {
        id: 4,
        jobTitle: "Marketing Manager",
        company: "Brand Excellence Co.",
        testDate: "2025-11-30",
        testTime: "11:00",
        duration: 30,
        questions: 10,
        status: "upcoming",
        type: "online"
    }
];

// Sample questions
const testQuestions = {
    1: [ // Full Stack Developer
        {
            question: "Apa yang dimaksud dengan RESTful API?",
            options: [
                "Protokol untuk transfer file",
                "Arsitektur untuk web service menggunakan HTTP",
                "Database management system",
                "Framework JavaScript"
            ],
            correct: 1
        },
        {
            question: "Apa fungsi utama dari React Hooks?",
            options: [
                "Menghubungkan ke database",
                "Membuat komponen class",
                "Mengelola state dan lifecycle di functional component",
                "Styling komponen"
            ],
            correct: 2
        },
        {
            question: "Apa perbedaan antara SQL dan NoSQL?",
            options: [
                "SQL untuk web, NoSQL untuk mobile",
                "SQL relasional, NoSQL non-relasional",
                "Tidak ada perbedaan",
                "SQL lebih cepat dari NoSQL"
            ],
            correct: 1
        }
    ],
    2: [ // UI/UX Designer
        {
            question: "Apa yang dimaksud dengan User Persona?",
            options: [
                "Nama pengguna aplikasi",
                "Representasi fiktif dari target user",
                "Database pengguna",
                "Desain interface"
            ],
            correct: 1
        },
        {
            question: "Apa prinsip dasar dari Design Thinking?",
            options: [
                "Empati, Define, Ideate, Prototype, Test",
                "Coding, Testing, Deploy",
                "Planning, Execution, Review",
                "Design, Build, Launch"
            ],
            correct: 0
        }
    ]
};

// Current test state
let currentTest = null;
let currentQuestionIndex = 0;
let userAnswers = [];
let testTimer = null;
let timeRemaining = 0;

// Get or initialize test results
function getTestResults() {
    return JSON.parse(localStorage.getItem('testResults') || '[]');
}

function saveTestResult(result) {
    const results = getTestResults();
    results.push(result);
    localStorage.setItem('testResults', JSON.stringify(results));
}

// Calculate time until test
function getTimeUntilTest(testDate, testTime) {
    const now = new Date();
    const testDateTime = new Date(`${testDate}T${testTime}`);
    const diff = testDateTime - now;
    
    if (diff < 0) return "Sudah berlalu";
    
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    
    if (days > 0) return `${days} hari lagi`;
    if (hours > 0) return `${hours} jam lagi`;
    return `${minutes} menit lagi`;
}

// Populate test list
function populateTestList() {
    const container = document.getElementById('testList');
    const results = getTestResults();
    
    if (onlineTests.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-clipboard-list"></i>
                <h3>Belum Ada Tes Online</h3>
                <p>Anda belum memiliki jadwal tes. Tes akan muncul setelah lamaran Anda diproses.</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = onlineTests.map(test => {
        const userResult = results.find(r => r.testId === test.id && r.userId === user.id);
        const actualStatus = userResult ? 'completed' : test.status;
        
        const statusClasses = {
            upcoming: 'test-upcoming',
            active: 'test-active',
            expired: 'test-expired',
            completed: 'test-completed'
        };
        
        const statusText = {
            upcoming: 'Akan Datang',
            active: 'Aktif',
            expired: 'Kadaluarsa',
            completed: 'Selesai'
        };
        
        const timeUntil = getTimeUntilTest(test.testDate, test.testTime);
        
        return `
            <div class="test-card">
                <div class="test-header">
                    <div>
                        <div class="test-title">${test.jobTitle}</div>
                        <div class="test-company">
                            <i class="fas fa-building"></i> ${test.company}
                        </div>
                    </div>
                    <span class="test-status-badge ${statusClasses[actualStatus]}">
                        ${statusText[actualStatus]}
                    </span>
                </div>
                
                <div class="test-info">
                    <div class="info-item">
                        <i class="fas fa-calendar"></i>
                        <span>${new Date(test.testDate).toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</span>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-clock"></i>
                        <span>${test.testTime} WIB</span>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-hourglass-half"></i>
                        <span>${test.duration} menit</span>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-question-circle"></i>
                        <span>${test.questions} soal</span>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-${test.type === 'online' ? 'laptop' : 'map-marker-alt'}"></i>
                        <span>${test.type === 'online' ? 'Online' : 'Offline'}</span>
                    </div>
                    ${actualStatus === 'upcoming' ? `
                    <div class="info-item countdown">
                        <i class="fas fa-bell"></i>
                        <span>${timeUntil}</span>
                    </div>
                    ` : ''}
                </div>
                
                <div class="test-actions">
                    ${actualStatus === 'active' && test.type === 'online' ? `
                        <button class="btn-start-test" onclick="startTest(${test.id})">
                            <i class="fas fa-play"></i> Mulai Tes Sekarang
                        </button>
                    ` : actualStatus === 'completed' ? `
                        <button class="btn-view-result" onclick="viewResult(${test.id})">
                            <i class="fas fa-chart-bar"></i> Lihat Hasil
                        </button>
                    ` : actualStatus === 'upcoming' && test.type === 'offline' ? `
                        <button class="btn-disabled" disabled>
                            <i class="fas fa-map-marker-alt"></i> Tes Offline di Kantor
                        </button>
                    ` : `
                        <button class="btn-disabled" disabled>
                            <i class="fas fa-lock"></i> Belum Waktunya
                        </button>
                    `}
                    <button class="btn-view-result" onclick="viewTestInfo(${test.id})">
                        <i class="fas fa-info-circle"></i> Info Detail
                    </button>
                </div>
            </div>
        `;
    }).join('');
}

// Start test - Make it global
window.startTest = function(testId) {
    const test = onlineTests.find(t => t.id === testId);
    if (!test) return;
    
    if (!testQuestions[testId]) {
        alert('❌ Soal tes belum tersedia. Hubungi HRD untuk informasi lebih lanjut.');
        return;
    }
    
    if (confirm(`🎯 Mulai Tes: ${test.jobTitle}\n\n` +
                `⏱️ Durasi: ${test.duration} menit\n` +
                `📝 Jumlah Soal: ${test.questions}\n\n` +
                `⚠️ Setelah dimulai, tes tidak bisa diulang!\n\n` +
                `Apakah Anda siap?`)) {
        
        currentTest = test;
        currentQuestionIndex = 0;
        userAnswers = new Array(testQuestions[testId].length).fill(null);
        timeRemaining = test.duration * 60; // Convert to seconds
        
        document.getElementById('testModal').classList.add('active');
        document.body.style.overflow = 'hidden';
        
        startTimer();
        showQuestion();
    }
}

// Start timer
function startTimer() {
    updateTimerDisplay();
    
    testTimer = setInterval(() => {
        timeRemaining--;
        updateTimerDisplay();
        
        if (timeRemaining <= 0) {
            clearInterval(testTimer);
            alert('⏰ Waktu habis! Tes akan otomatis disubmit.');
            submitTest();
        }
    }, 1000);
}

// Update timer display
function updateTimerDisplay() {
    const minutes = Math.floor(timeRemaining / 60);
    const seconds = timeRemaining % 60;
    document.getElementById('timeRemaining').textContent = 
        `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
}

// Show question
function showQuestion() {
    const questions = testQuestions[currentTest.id];
    const question = questions[currentQuestionIndex];
    
    document.getElementById('questionContainer').innerHTML = `
        <div class="question-number">
            Soal ${currentQuestionIndex + 1} dari ${questions.length}
        </div>
        <div class="question-text">${question.question}</div>
        <div class="answer-options">
            ${question.options.map((option, index) => `
                <div class="answer-option ${userAnswers[currentQuestionIndex] === index ? 'selected' : ''}" 
                     onclick="selectAnswer(${index})">
                    <div class="answer-radio"></div>
                    <span>${option}</span>
                </div>
            `).join('')}
        </div>
    `;
    
    // Update navigation buttons
    document.getElementById('prevQuestion').style.display = currentQuestionIndex > 0 ? 'block' : 'none';
    document.getElementById('nextQuestion').style.display = currentQuestionIndex < questions.length - 1 ? 'block' : 'none';
    document.getElementById('submitTest').style.display = currentQuestionIndex === questions.length - 1 ? 'block' : 'none';
}

// Select answer is now global (defined above)

// Navigation
document.getElementById('prevQuestion').addEventListener('click', () => {
    if (currentQuestionIndex > 0) {
        currentQuestionIndex--;
        showQuestion();
    }
});

document.getElementById('nextQuestion').addEventListener('click', () => {
    const questions = testQuestions[currentTest.id];
    if (currentQuestionIndex < questions.length - 1) {
        currentQuestionIndex++;
        showQuestion();
    }
});

// Submit test
document.getElementById('submitTest').addEventListener('click', () => {
    const unanswered = userAnswers.filter(a => a === null).length;
    
    if (unanswered > 0) {
        if (!confirm(`⚠️ Ada ${unanswered} soal yang belum dijawab!\n\nApakah Anda yakin ingin submit?`)) {
            return;
        }
    }
    
    submitTest();
});

function submitTest() {
    clearInterval(testTimer);
    
    // Calculate score
    const questions = testQuestions[currentTest.id];
    let correctAnswers = 0;
    
    questions.forEach((q, index) => {
        if (userAnswers[index] === q.correct) {
            correctAnswers++;
        }
    });
    
    const score = Math.round((correctAnswers / questions.length) * 100);
    
    // Save result
    const result = {
        id: Date.now(),
        testId: currentTest.id,
        userId: user.id,
        jobTitle: currentTest.jobTitle,
        company: currentTest.company,
        score: score,
        correctAnswers: correctAnswers,
        totalQuestions: questions.length,
        completedDate: new Date().toLocaleDateString('id-ID'),
        timeTaken: (currentTest.duration * 60) - timeRemaining
    };
    
    saveTestResult(result);
    
    // Close modal
    document.getElementById('testModal').classList.remove('active');
    document.body.style.overflow = 'auto';
    
    // Show result
    alert(`🎉 Tes Selesai!\n\n` +
          `📊 Skor Anda: ${score}%\n` +
          `✅ Jawaban Benar: ${correctAnswers}/${questions.length}\n\n` +
          `Hasil tes akan dikirim ke HRD untuk review.`);
    
    // Refresh list
    populateTestList();
}

// View result
function viewResult(testId) {
    const results = getTestResults();
    const result = results.find(r => r.testId === testId && r.userId === user.id);
    
    if (result) {
        const timeTaken = Math.floor(result.timeTaken / 60);
        alert(`📊 HASIL TES\n\n` +
              `🏢 Posisi: ${result.jobTitle}\n` +
              `🏭 Perusahaan: ${result.company}\n\n` +
              `📈 Skor: ${result.score}%\n` +
              `✅ Benar: ${result.correctAnswers}/${result.totalQuestions}\n` +
              `⏱️ Waktu: ${timeTaken} menit\n` +
              `📅 Tanggal: ${result.completedDate}\n\n` +
              `Status: ${result.score >= 70 ? '✅ LULUS' : '❌ TIDAK LULUS'}`);
    }
};

// View test info - Make it global
window.viewTestInfo = function(testId) {
    const test = onlineTests.find(t => t.id === testId);
    if (test) {
        alert(`ℹ️ INFO TES ONLINE\n\n` +
              `🏢 Posisi: ${test.jobTitle}\n` +
              `🏭 Perusahaan: ${test.company}\n\n` +
              `📅 Tanggal: ${new Date(test.testDate).toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}\n` +
              `🕐 Waktu: ${test.testTime} WIB\n` +
              `⏱️ Durasi: ${test.duration} menit\n` +
              `📝 Jumlah Soal: ${test.questions}\n` +
              `💻 Tipe: ${test.type === 'online' ? 'Online' : 'Offline di Kantor'}\n\n` +
              `${test.type === 'online' ? '📱 Dapat dikerjakan dari mana saja' : '📍 Harap datang ke kantor sesuai jadwal'}`);
    }
};

// Select answer - Make it global
window.selectAnswer = function(answerIndex) {
    userAnswers[currentQuestionIndex] = answerIndex;
    showQuestion();
};

// Initialize
populateTestList();