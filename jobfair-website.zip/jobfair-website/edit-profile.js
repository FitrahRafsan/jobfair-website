// edit-profile.js

// Check authentication
function checkAuth() {
    const currentUser = localStorage.getItem('currentUser');
    if (!currentUser) {
        alert('⚠️ Silakan login terlebih dahulu!');
        window.location.href = 'login.html';
        return null;
    }
    return JSON.parse(currentUser);
}

let user = checkAuth();
if (!user) {
    window.location.href = 'login.html';
}

// Update navbar
document.getElementById('userName').textContent = user.name;
document.getElementById('userEmail').textContent = user.email;

// Logout handler
document.getElementById('logoutBtn').addEventListener('click', function() {
    if (confirm('Apakah Anda yakin ingin logout?')) {
        localStorage.removeItem('currentUser');
        window.location.href = 'login.html';
    }
});

// Load current photo
function loadCurrentPhoto() {
    const savedPhoto = localStorage.getItem(`profilePhoto_${user.id}`);
    if (savedPhoto) {
        document.getElementById('currentPhoto').src = savedPhoto;
        document.getElementById('currentPhoto').style.display = 'block';
        document.getElementById('currentPhotoPlaceholder').style.display = 'none';
        document.getElementById('removePhotoBtn').style.display = 'inline-block';
    } else {
        const initial = user.name.charAt(0).toUpperCase();
        document.getElementById('photoInitial').textContent = initial;
    }
}

// Load user profile data
function loadProfileData() {
    const profileData = localStorage.getItem(`profileData_${user.id}`);
    
    if (profileData) {
        const data = JSON.parse(profileData);
        document.getElementById('editName').value = data.name || user.name;
        document.getElementById('editEmail').value = data.email || user.email;
        document.getElementById('editPhone').value = data.phone || user.phone;
        document.getElementById('editBirthdate').value = data.birthdate || '';
        document.getElementById('editAddress').value = data.address || '';
        document.getElementById('editEducation').value = data.education || '';
        document.getElementById('editMajor').value = data.major || '';
        document.getElementById('editExperience').value = data.experience || '';
        document.getElementById('editSkills').value = data.skills || '';
    } else {
        // Load default from user object
        document.getElementById('editName').value = user.name;
        document.getElementById('editEmail').value = user.email;
        document.getElementById('editPhone').value = user.phone;
    }
}

// Handle photo upload
document.getElementById('photoUpload').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        if (file.size > 5 * 1024 * 1024) {
            alert('⚠️ Ukuran file terlalu besar! Maksimal 5MB.');
            return;
        }

        const reader = new FileReader();
        reader.onload = function(event) {
            const photoData = event.target.result;
            localStorage.setItem(`profilePhoto_${user.id}`, photoData);
            
            document.getElementById('currentPhoto').src = photoData;
            document.getElementById('currentPhoto').style.display = 'block';
            document.getElementById('currentPhotoPlaceholder').style.display = 'none';
            document.getElementById('removePhotoBtn').style.display = 'inline-block';
            
            alert('✅ Foto berhasil diupload!');
        };
        reader.readAsDataURL(file);
    }
});

// Remove photo
document.getElementById('removePhotoBtn').addEventListener('click', function() {
    if (confirm('Apakah Anda yakin ingin menghapus foto profil?')) {
        localStorage.removeItem(`profilePhoto_${user.id}`);
        document.getElementById('currentPhoto').style.display = 'none';
        document.getElementById('currentPhotoPlaceholder').style.display = 'flex';
        document.getElementById('removePhotoBtn').style.display = 'none';
        alert('✅ Foto profil berhasil dihapus!');
    }
});

// Toggle password visibility
function togglePassword(inputId) {
    const input = document.getElementById(inputId);
    const btn = input.nextElementSibling;
    const icon = btn.querySelector('i');
    
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

// Handle form submission
document.getElementById('editProfileForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const newName = document.getElementById('editName').value;
    const newEmail = document.getElementById('editEmail').value;
    const newPhone = document.getElementById('editPhone').value;
    const birthdate = document.getElementById('editBirthdate').value;
    const address = document.getElementById('editAddress').value;
    const education = document.getElementById('editEducation').value;
    const major = document.getElementById('editMajor').value;
    const experience = document.getElementById('editExperience').value;
    const skills = document.getElementById('editSkills').value;
    const oldPassword = document.getElementById('oldPassword').value;
    const newPassword = document.getElementById('newPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    
    // Validate password change if any password field is filled
    if (oldPassword || newPassword || confirmPassword) {
        if (!oldPassword) {
            alert('⚠️ Masukkan password lama Anda!');
            return;
        }
        if (oldPassword !== user.password) {
            alert('❌ Password lama tidak sesuai!');
            return;
        }
        if (!newPassword) {
            alert('⚠️ Masukkan password baru!');
            return;
        }
        if (newPassword.length < 6) {
            alert('⚠️ Password baru minimal 6 karakter!');
            return;
        }
        if (newPassword !== confirmPassword) {
            alert('❌ Konfirmasi password tidak sesuai!');
            return;
        }
    }
    
    // Check if email is already used by another user
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const emailExists = users.find(u => u.email === newEmail && u.id !== user.id);
    if (emailExists) {
        alert('❌ Email sudah digunakan oleh user lain!');
        return;
    }
    
    // Update user data
    user.name = newName;
    user.email = newEmail;
    user.phone = newPhone;
    if (newPassword) {
        user.password = newPassword;
    }
    
    // Update in users array
    const userIndex = users.findIndex(u => u.id === user.id);
    if (userIndex !== -1) {
        users[userIndex] = user;
        localStorage.setItem('users', JSON.stringify(users));
    }
    
    // Update current user
    localStorage.setItem('currentUser', JSON.stringify(user));
    
    // Save additional profile data
    const profileData = {
        name: newName,
        email: newEmail,
        phone: newPhone,
        birthdate: birthdate,
        address: address,
        education: education,
        major: major,
        experience: experience,
        skills: skills
    };
    localStorage.setItem(`profileData_${user.id}`, JSON.stringify(profileData));
    
    alert('✅ Profil berhasil diperbarui!\n\n' + 
          (newPassword ? 'Password Anda juga telah diubah.' : ''));
    
    window.location.href = 'profile.html';
});

// Initialize
loadCurrentPhoto();
loadProfileData();