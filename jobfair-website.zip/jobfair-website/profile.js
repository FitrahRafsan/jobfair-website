// profile.js

// Check authentication
function checkAuth() {
    const currentUser = localStorage.getItem('currentUser');
    if (!currentUser) {
        alert('⚠️ Silakan login terlebih dahulu!');
        window.location.href = 'login.html';
        return null;
    }
    return JSON.parse(currentUser);
}

const user = checkAuth();
if (!user) {
    window.location.href = 'login.html';
}

// Logout handler
document.getElementById('logoutBtn').addEventListener('click', function() {
    if (confirm('Apakah Anda yakin ingin logout?')) {
        localStorage.removeItem('currentUser');
        window.location.href = 'login.html';
    }
});

// Load profile photo
function loadProfilePhoto() {
    const savedPhoto = localStorage.getItem(`profilePhoto_${user.id}`);
    if (savedPhoto) {
        document.getElementById('profilePhoto').src = savedPhoto;
        document.getElementById('profilePhoto').style.display = 'block';
        document.getElementById('profilePhotoPlaceholder').style.display = 'none';
    } else {
        // Show initial letter
        const initial = user.name.charAt(0).toUpperCase();
        document.getElementById('profileInitial').textContent = initial;
    }
}

// Handle photo upload
document.getElementById('photoUpload').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        if (file.size > 5 * 1024 * 1024) { // 5MB limit
            alert('⚠️ Ukuran file terlalu besar! Maksimal 5MB.');
            return;
        }

        const reader = new FileReader();
        reader.onload = function(event) {
            const photoData = event.target.result;
            
            // Save to localStorage
            localStorage.setItem(`profilePhoto_${user.id}`, photoData);
            
            // Display photo
            document.getElementById('profilePhoto').src = photoData;
            document.getElementById('profilePhoto').style.display = 'block';
            document.getElementById('profilePhotoPlaceholder').style.display = 'none';
            
            alert('✅ Foto profil berhasil diupdate!');
        };
        reader.readAsDataURL(file);
    }
});

// Load user data
document.getElementById('userName').textContent = user.name;
document.getElementById('userEmail').textContent = user.email;
document.getElementById('profileName').textContent = user.name;
document.getElementById('profileEmail').innerHTML = '<i class="fas fa-envelope"></i> ' + user.email;
document.getElementById('profilePhone').innerHTML = '<i class="fas fa-phone"></i> ' + user.phone;
document.getElementById('userId').textContent = '#' + user.id.toString().padStart(5, '0');

// Set join date (using current date as demo)
const joinDate = new Date().toLocaleDateString('id-ID', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
});
document.getElementById('joinDate').textContent = joinDate;

// Load application statistics
function loadStatistics() {
    const applications = JSON.parse(localStorage.getItem('applications') || '[]');
    const userApplications = applications.filter(app => app.userId === user.id);
    
    const totalApps = userApplications.length;
    const pendingApps = userApplications.filter(app => 
        app.status === 'Pending' || app.status === 'In Review'
    ).length;
    const acceptedApps = userApplications.filter(app => 
        app.status === 'Accepted'
    ).length;
    
    const successRate = totalApps > 0 ? Math.round((acceptedApps / totalApps) * 100) : 0;
    
    document.getElementById('totalApps').textContent = totalApps;
    document.getElementById('pendingApps').textContent = pendingApps;
    document.getElementById('acceptedApps').textContent = acceptedApps;
    document.getElementById('successRate').textContent = successRate + '%';
    document.getElementById('successRateBar').style.width = successRate + '%';
    
    // Show badges based on activity
    if (totalApps > 0) {
        document.getElementById('firstAppBadge').style.display = 'inline-block';
    }
    if (totalApps >= 3) {
        document.getElementById('activeUserBadge').style.display = 'inline-block';
    }
    
    // Load recent activity
    loadRecentActivity(userApplications);
}

// Load recent activity
function loadRecentActivity(applications) {
    const container = document.getElementById('recentActivity');
    
    if (applications.length === 0) {
        container.innerHTML = `
            <p style="color: #64748b; text-align: center; padding: 20px;">
                <i class="fas fa-info-circle"></i> Belum ada aktivitas. Mulai lamar pekerjaan sekarang!
            </p>
        `;
        return;
    }
    
    // Get last 5 applications
    const recentApps = applications.slice(-5).reverse();
    
    container.innerHTML = recentApps.map(app => `
        <div class="info-row">
            <span class="info-label">
                <i class="fas fa-briefcase" style="color: #6366f1;"></i> 
                Melamar ${app.jobTitle}
            </span>
            <span class="info-value">${app.date}</span>
        </div>
    `).join('');
}

// Edit profile function
function editProfile() {
    window.location.href = 'edit-profile.html';
}

// Initialize
loadProfilePhoto();
loadStatistics();